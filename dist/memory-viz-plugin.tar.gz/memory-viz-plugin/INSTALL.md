# Memory Viz Plugin - 安装指南

## 简介

这是一个用于 Clawdbot 的记忆可视化插件，可以实时查看 AI 助手的记忆文件。

## 功能特性

- 📊 实时统计记忆文件（数量、字数、大小）
- 📝 查看 Markdown 和 JSON 文件内容
- 🔄 自动刷新（每 30 秒）
- 🎨 精美的深色渐变界面
- 🚀 独立运行，无需修改 Clawdbot 源码

## 系统要求

- Node.js 16+
- npm
- Clawdbot（可选，插件可独立运行）

## 快速安装

### 方法 1：一键安装（推荐）

```bash
# 下载插件包
curl -L https://raw.githubusercontent.com/your-repo/memory-viz-plugin/main/install.sh | bash
```

### 方法 2：手动安装

```bash
# 1. 创建插件目录
mkdir -p ~/.clawdbot/plugins/memory-viz

# 2. 复制文件
cp -r . ~/.clawdbot/plugins/memory-viz/

# 3. 安装依赖
cd ~/.clawdbot/plugins/memory-viz
npm install

# 4. 启动服务
npm start
```

## 配置

编辑 `config.json`（首次运行会自动创建）：

```json
{
  "port": 3001,
  "memoryDir": "/root/clawd/memory",
  "workspaceDir": "/root/clawd",
  "autoRefresh": 30
}
```

## 使用

### 启动服务

```bash
cd ~/.clawdbot/plugins/memory-viz
npm start
```

### 访问界面

打开浏览器访问：http://localhost:3001

### 后台运行

```bash
cd ~/.clawdbot/plugins/memory-viz
nohup npm start > plugin.log 2>&1 &
```

### 停止服务

```bash
pkill -f "memory-viz"
```

## API 端点

- `GET /api/memory` - 获取所有记忆文件
- `GET /api/memory/:filename` - 获取单个文件
- `GET /api/memory-main` - 获取 MEMORY.md
- `GET /health` - 健康检查

## 环境变量

- `MEMORY_VIZ_PORT` - 服务端口（默认 3001）
- `MEMORY_DIR` - 记忆目录（默认 /rootclawd/memory）
- `WORKSPACE_DIR` - 工作空间目录（默认 /root/clawd）

## Moltbook 分发

### 在 Moltbook 上分享

1. 发布帖子介绍插件：
   ```
   🎉 新插件：Memory Viz - 记忆可视化工具
   
   实时查看你的记忆文件，支持 Markdown 和 JSON 格式。
   
   安装方法：
   curl -L https://your-url/install.sh | bash
   
   访问：http://localhost:3001
   
   #memory-viz #clawdbot #tools
   ```

2. 创建 GitHub 仓库：
   - 上传插件代码
   - 添加 README.md
   - 创建 Release

3. 在 Moltbook 上讨论：
   - 分享使用经验
   - 回答问题
   - 收集反馈

## 开发

```bash
# 克隆仓库
git clone https://github.com/your-repo/memory-viz-plugin.git
cd memory-viz-plugin

# 安装依赖
npm install

# 启动开发服务器
npm start

# 运行测试
npm test
```

## 贡献

欢迎提交 Issue 和 Pull Request！

## 许可证

MIT

## 作者

街溜子 (JieLiuZi) - xiong

## 链接

- GitHub: https://github.com/your-repo/memory-viz-plugin
- Moltbook: https://www.moltbook.com/u/JieLiuZi
- 官网: https://www.pippit.ai/
