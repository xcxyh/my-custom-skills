#!/bin/bash

# Memory Viz Plugin - 一键安装脚本

set -e

echo "🐶 Memory Viz Plugin 安装程序"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# 配置
PLUGIN_NAME="memory-viz"
INSTALL_DIR="${CLAWDBOT_HOME:-$HOME/.clawdbot}/plugins/$PLUGIN_NAME"
TEMP_DIR="/tmp/memory-viz-install"

# 检测平台
OS=$(uname -s)
ARCH=$(uname -m)

echo "📋 系统信息:"
echo "   OS: $OS"
echo "   ARCH: $ARCH"
echo ""

# 检查 Node.js
if ! command -v node &> /dev/null; then
    echo "❌ 错误：未找到 Node.js"
    echo "   请先安装 Node.js: https://nodejs.org/"
    exit 1
fi

NODE_VERSION=$(node -v)
echo "✅ Node.js: $NODE_VERSION"

# 检查 npm
if ! command -v npm &> /dev/null; then
    echo "❌ 错误：未找到 npm"
    exit 1
fi

NPM_VERSION=$(npm -v)
echo "✅ npm: $NPM_VERSION"
echo ""

# 创建安装目录
echo "📁 安装目录: $INSTALL_DIR"
mkdir -p "$INSTALL_DIR"

# 下载插件（这里假设从 GitHub 下载）
echo "⬇️  下载插件..."
# 实际使用时替换为真实的下载 URL
# curl -L https://github.com/your-repo/memory-viz-plugin/archive/main.tar.gz | tar -xz -C "$TEMP_DIR"

# 临时：从本地复制
TEMP_DIR="/tmp/memory-viz-install"
rm -rf "$TEMP_DIR"
mkdir -p "$TEMP_DIR"
cp -r /root/clawd/plugins/memory-viz-plugin/* "$TEMP_DIR/"

# 复制文件
echo "📦 安装文件..."
cp -r "$TEMP_DIR"/* "$INSTALL_DIR/"

# 安装依赖
echo "📥 安装依赖..."
cd "$INSTALL_DIR"
npm install --silent

# 清理临时文件
rm -rf "$TEMP_DIR"

# 创建启动脚本
cat > "$INSTALL_DIR/start.sh" << 'EOF'
#!/bin/bash
cd "$(dirname "$0")"
nohup node index.js > plugin.log 2>&1 &
echo "✅ Memory Viz Plugin 已启动"
echo "📝 日志: $PWD/plugin.log"
echo "🌐 访问: http://localhost:3001"
EOF
chmod +x "$INSTALL_DIR/start.sh"

# 创建停止脚本
cat > "$INSTALL_DIR/stop.sh" << 'EOF'
#!/bin/bash
pkill -f "memory-viz" || true
echo "✅ Memory Viz Plugin 已停止"
EOF
chmod +x "$INSTALL_DIR/stop.sh"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✅ 安装完成！"
echo ""
echo "📁 安装位置: $INSTALL_DIR"
echo ""
echo "使用方法:"
echo "  启动: cd $INSTALL_DIR && bash start.sh"
echo "  停止: cd $INSTALL_DIR && bash stop.sh"
echo "  访问: http://localhost:3001"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
